﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using AdminProject.Data;
using AdminProject.Models;

namespace AdminProject.Pages.Members
{
    public class IndexModel : PageModel
    {
        private readonly AdminProject.Data.AdminProjectContext _context;

        public IndexModel(AdminProject.Data.AdminProjectContext context)
        {
            _context = context;
        }

        public IList<AllMembers> AllMembers { get;set; }

        public async Task OnGetAsync()
        {
            AllMembers = await _context.AllMembers.ToListAsync();
        }
    }
}
